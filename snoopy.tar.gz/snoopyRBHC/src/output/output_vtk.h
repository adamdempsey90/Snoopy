void output_vtk(struct Field fldi, const int n, double t);
void init_output_vtk();
void finish_output_vtk();
