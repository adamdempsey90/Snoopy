void init_timevar();
void output_timevar(const struct Field fldi,
					const double t);