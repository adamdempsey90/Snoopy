void output_dump( const struct Field fldi,
				  const double t);
				  
void read_dump(   struct Field fldo,
				  double *t,
				  char dump_file[]);