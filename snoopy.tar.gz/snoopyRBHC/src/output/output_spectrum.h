void output1Dspectrum(const struct Field fldi, const double ti);
void init1Dspectrum();
void output1Dprofile(const struct Field fldi, const double ti);
void init1Dprofile();
