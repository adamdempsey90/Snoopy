int file_exist(char filename[]);
int check_file_size(char *filename, long int filesize);